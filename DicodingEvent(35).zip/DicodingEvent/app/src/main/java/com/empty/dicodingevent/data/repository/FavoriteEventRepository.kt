package com.empty.dicodingevent.data.repository

import androidx.lifecycle.LiveData
import com.empty.dicodingevent.database.FavoriteEventDao
import com.empty.dicodingevent.database.FavoriteEvent

class FavoriteEventRepository(private val favoriteEventDao: FavoriteEventDao) {
    fun getFavoriteEvents(): LiveData<List<FavoriteEvent>> {
        return favoriteEventDao.getFavoriteEvents()
    }


}
