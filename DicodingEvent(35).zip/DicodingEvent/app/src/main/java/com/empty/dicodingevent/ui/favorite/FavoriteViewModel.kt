package com.empty.dicodingevent.ui.favorite

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.empty.dicodingevent.data.repository.FavoriteEventRepository
import com.empty.dicodingevent.database.FavoriteEvent
import kotlinx.coroutines.launch

class FavoriteViewModel(private val repository: FavoriteEventRepository) : ViewModel() {

    val favoriteEvents: LiveData<List<FavoriteEvent>> = repository.getFavoriteEvents()

}