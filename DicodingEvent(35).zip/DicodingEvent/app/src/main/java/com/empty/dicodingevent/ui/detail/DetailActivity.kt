package com.empty.dicodingevent.ui.detail

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.empty.dicodingevent.data.response.ListEventsItem
import androidx.core.text.HtmlCompat
import androidx.room.Room
import com.empty.dicodingevent.R
import com.empty.dicodingevent.database.AppDatabase
import com.empty.dicodingevent.database.FavoriteEvent
import com.empty.dicodingevent.databinding.ActivityDetailBinding
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var database: AppDatabase
    private var isFavorite: Boolean = false
    private lateinit var currentEvent: ListEventsItem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)

        val event = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("event", ListEventsItem::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra("event")
        }

        event?.let {
            currentEvent = it
            setupEventDetails(it)
            checkIfFavorite(it.id.toString())
        } ?: run {
            Snackbar.make(binding.root, "Event tidak ditemukan", Snackbar.LENGTH_SHORT).show()
            finish()
        }

        binding.btnFavorite.setOnClickListener {
            if (isFavorite) {
                removeFromFavorites(currentEvent.id.toString())
            } else {
                addToFavorites(currentEvent)
            }
        }
    }

    private fun setupEventDetails(event: ListEventsItem) {
        with(binding) {
            tvDetailName.text = event.name
            tvDetailOwnername.text = event.ownerName
            tvDetailBegintime.text = event.beginTime
            tvDetailQuota.text =
                getString(R.string.quota_left, event.quota?.minus(event.registrants ?: 0))
            tvDetailDescription.text = event.description?.let { desc ->
                HtmlCompat.fromHtml(desc, HtmlCompat.FROM_HTML_MODE_LEGACY)
            } ?: ""
            Glide.with(this@DetailActivity).load(event.imageLogo ?: event.mediaCover)
                .into(ivImageUpcoming)
            btnDetailSign.setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW)
                intent.data = Uri.parse(event.link)
                startActivity(intent)
            }
        }
    }

    private fun addToFavorites(event: ListEventsItem) {
        val favoriteEvent = FavoriteEvent(
            id = event.id.toString(),
            name = event.name ?: "",
            mediaCover = event.mediaCover,
            host = event.ownerName,
            remainingQuota = event.quota.toString(),
            time = event.beginTime,
            description = event.description,
            link = event.link,
            summary = event.summary,
            category = event.category
        )
        CoroutineScope(Dispatchers.IO).launch {
            database.favoriteEventDao().insert(favoriteEvent)
            withContext(Dispatchers.Main) {
                isFavorite = true
                updateFavoriteButtonText()
                Snackbar.make(
                    binding.root,
                    "${event.name} ditambahkan ke favorit",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun removeFromFavorites(eventId: String) {
        CoroutineScope(Dispatchers.IO).launch {
            database.favoriteEventDao()
                .deleteEventById(eventId.toInt())  // Ensure you are passing the correct ID type
            withContext(Dispatchers.Main) {
                isFavorite = false
                updateFavoriteButtonText()
                Snackbar.make(
                    binding.root,
                    "${currentEvent.name} dihapus dari favorit",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun checkIfFavorite(eventId: String) {
        CoroutineScope(Dispatchers.IO).launch {
            isFavorite = database.favoriteEventDao().isFavorite(eventId) > 0
            withContext(Dispatchers.Main) {
                updateFavoriteButtonText()
            }
        }
    }

    private fun updateFavoriteButtonText() {
        if (isFavorite) {
            binding.btnFavorite.setImageResource(R.drawable.baseline_favorite_24)

        } else {

            binding.btnFavorite.setImageResource(R.drawable.baseline_favorite_border_24)
        }

    }
}
