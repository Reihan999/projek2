package com.empty.dicodingevent.ui.favorite

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.empty.dicodingevent.data.repository.FavoriteEventRepository
import com.empty.dicodingevent.data.response.ListEventsItem
import com.empty.dicodingevent.database.AppDatabase
import com.empty.dicodingevent.database.FavoriteEvent
import com.empty.dicodingevent.databinding.FragmentFavoriteBinding
import com.empty.dicodingevent.ui.detail.DetailActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FavoriteFragment : Fragment() {

    private var _binding: FragmentFavoriteBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: FavoriteViewModel
    private lateinit var adapter: FavoriteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val dao = AppDatabase.getDatabase(requireContext()).favoriteEventDao()
        val repository = FavoriteEventRepository(dao)
        val factory = FavoriteViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(FavoriteViewModel::class.java)

        initializeRecyclerView()



        // Observe favorite events
        viewModel.favoriteEvents.observe(viewLifecycleOwner) { favorites ->
            val items = arrayListOf<ListEventsItem>()
            favorites.map {
                val item = ListEventsItem(
                    id = it.id.toInt(),
                    name = it.name,
                    imageLogo = it.mediaCover,
                    quota = it.remainingQuota?.toInt(),
                    ownerName = it.host,
                    beginTime = it.time,
                    summary = it.summary,
                    link = it.link,
                    description = it.description
                )
                items.add(item)
            }
            adapter.submitList(items)
        }

    }



    private fun initializeRecyclerView() {
        adapter = FavoriteAdapter(requireContext()) { selectedEvent ->
            // Handle item click
            val intent = Intent(requireContext(), DetailActivity::class.java)
            intent.putExtra("event", selectedEvent)
            startActivity(intent)

        }

        binding.rvFavoriteEvents.layoutManager = LinearLayoutManager(context)
        binding.rvFavoriteEvents.adapter = adapter



    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
